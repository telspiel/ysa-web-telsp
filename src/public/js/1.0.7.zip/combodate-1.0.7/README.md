# Combodate
Dropdown date and time picker.  
This plugin converts `<input type="text">` into dropdown elements to pick day, month, year, hour, minutes and seconds.

* support of date, time, datetime
* 12h / 24h format
* based on [moment.js](http://momentjs.com)


## Demo, Docs and Download
**http://vitalets.github.com/combodate**


## Installation
````
bower install combodate
````
or [download latest version](http://vitalets.github.com/combodate).

## jsFiddle
http://jsfiddle.net/5m6gG/

## License
Copyright (c) 2013 Vitaliy Potapov  
Released under the MIT license.